Data export for alex@example-foods.co.uk
Workspace: Sam's workspace
Created: 2026-10-16T07:46:21.232310+00:00

person.json holds every record this workspace keeps about this email address:
contacts (where the address was found), leads (the person's profile and the lawful basis
for contacting them), companies, emails sent to them, their replies, campaign enrollments,
delivery events and any do-not-contact entries.
